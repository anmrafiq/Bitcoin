using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitFlyer
{
   public class Program
    {

     


        static void LeftRotate(Transaction[] arr, int d, int n)
        {
            for (int i = 0; i < d; i++)
                LeftRotatebyOne(arr, n);
        }

        static void LeftRotatebyOne(Transaction[] arr, int n)
        {
            int i;
            Transaction temp = arr[0];
            for (i = 0; i < n - 1; i++)
                arr[i] = arr[i + 1];

            arr[i] = temp;
        }

        static void Main(string[] args)
            {
                Transaction[] transactions = new Transaction[12];
                transactions[0] = new Transaction { size = 57247, fee = 0.0887 };
                transactions[1] = new Transaction { size = 98732, fee = 0.1856 };
                transactions[2] = new Transaction { size = 134928, fee = 0.2307 };
                transactions[3] = new Transaction { size = 77275, fee = 0.1522 };
                transactions[4] = new Transaction { size = 29240, fee = 0.0532 };
                transactions[5] = new Transaction { size = 15440, fee = 0.025 };
                transactions[6] = new Transaction { size = 70820, fee = 0.1409 };
                transactions[7] = new Transaction { size = 139603, fee = 0.2541 };
                transactions[8] = new Transaction { size = 63718, fee = 0.1147 };
                transactions[9] = new Transaction { size = 143807, fee = 0.266 };
                transactions[10] = new Transaction { size = 190457, fee = 0.2933 };
                transactions[11] = new Transaction { size = 40572, fee = 0.0686 };

            double[] copyFee = new double[12];
            int[] copySize = new int[12];
            int tSize = 0;
            Transaction[] descTransactionsOnFee = new Transaction[12];
            Transaction[] descTransactionsOnSize = new Transaction[12];

            descTransactionsOnFee=transactions.OrderByDescending(i => i.fee).ToArray();
            

            

            double[] maxRewards = new double[12];

            for (int j = 0; j < 12; j++)
            {
                LeftRotate(descTransactionsOnFee, 1, 12);
                Transaction[] copyTransactions = new Transaction[12];
                copyTransactions = descTransactionsOnFee;
                double maxReward = 0;
                double totalFee = 0;
                int totalSize = 0;

                for (int i = 0; i < 12; i++)

                {
                    int t_size = 0;


                    t_size = totalSize + copyTransactions[i].size;

                    if (t_size < 1000000)
                    {
                        totalSize += copyTransactions[i].size;
                        totalFee += copyTransactions[i].fee;
                    }




                }
                maxReward = totalFee + 12.5;

                maxRewards[j] = maxReward;

              
            }

          

            //int l, m, size, totalSize = 0;
            //double totalFee = 0, maxReward = 0, fee;

            //for (int i = 0; i < 12; i++)

            //{
            //    int t_size = 0;


            //    t_size = totalSize + descTransactionsOnFee[i].size;

            //    if (t_size < 500000)
            //    {
            //        totalSize += descTransactionsOnFee[i].size;
            //        totalFee += descTransactionsOnFee[i].fee;
            //    }





            //}
            //maxReward = totalFee + 12.5;



            Console.WriteLine(maxRewards.Max());
            Console.ReadKey();




        }


    }
    public class Transaction
    {

        public int size { get; set; }
        public double fee { get; set; }

    }
}
